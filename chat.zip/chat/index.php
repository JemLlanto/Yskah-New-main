<?php
include ("sessionchecker.php");
include ("connection.php");
include ("head.php");

if (isset($_GET["user_id"])) {
    $_SESSION["user_id"] = $_GET["user_id"];
    header("location:admin_chatbox.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css\admin_product_preview6.css" />
</head>

<body>


    <div class="container my-3 p-3" style="background-color: lightgray; ">
        <div>
            <h5>Admin Chat</h5>
        </div>
        <div class="d-flex justify-content-start flex-column">
            <?php
            $users = mysqli_query($conn, 'SELECT * FROM user_table') or die("Query Failed" . mysqli_error());
            while ($row = mysqli_fetch_array($users)) {
                ?>
                <li>
                    <a
                        href="admin_chatbox.php?user_id = <?php echo $row['user_id']; ?>"><?php echo $row['first_name'] ?></a>
                </li>

            <?php } ?>
            <a href="register.php">register</a>
        </div>
    </div>

</body>

</html>