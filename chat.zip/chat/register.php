<?php
include ("sessionchecker.php");
include ("connection.php");
include ("head.php");

// if (isset($_GET["user_id"])) {
//     $_SESSION["user_id"] = $_GET["user_id"];
//     header("location:admin_chatbox.php");
// }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css\admin_product_preview6.css" />
</head>

<body>


    <div class="container my-3 p-3" style="background-color: lightgray; ">
        <div>register here</div>
        <div>
            <form action="">
                <input type="text">
            </form>
        </div>
    </div>

</body>

</html>