<?php
include ("sessionchecker.php");
include ("connection.php");
include ("head.php");

$users = mysqli_query($conn, "SELECT * FROM user_table WHERE user_id = '" . $_SESSION["user_id"] . "' ");
$user = mysqli_fetch_assoc($users);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css\admin_product_preview6.css" />
</head>

<body>

    <div class="container my-3 p-3" style="background-color: white; ">
        <div>
            <p>Hi <?php echo $user['username']; ?></p>
            <input type="text" id="from_user" value="<?php echo $user['user_id']; ?>" hidden>

            <p>Send Message to:</p>
            <ul>

                <?php
                $chats = mysqli_query($conn, 'SELECT * FROM user_table');
                while ($chat = mysqli_fetch_assoc($chats)) {
                    ?>
                    <li>
                        <a href="?to_user = <?php echo $chat['user_id']; ?>"><?php echo $chat['first_name'] ?></a>
                    </li>

                <?php } ?>
            </ul>
        </div>
        <div>
            <div>
                <p>
                    <?php
                    if (isset($_GET["to_user"])) {
                        $username = mysqli_query($conn, "SELECT * FROM user_table WHERE user_id = '" . $_GET["to_user"] . "' ");
                        $uname = mysqli_fetch_assoc($username);
                        ?>

                        <input type="text" value="<?php echo $_GET["to_user"] ?>" id="to_user" hidden>

                        <?php
                        echo $uname["username"];
                    } else {
                        $username = mysqli_query($conn, "SELECT * FROM user_table");
                        $uname = mysqli_fetch_assoc($username);
                        ?>

                        <input type="text" value="<?php echo $_SESSION["to_user"] ?>" id="to_user" hidden>

                        <?php
                        echo $uname["username"];
                    }
                    ?>
                </p>
            </div>
            <div>
                <?php
                if (isset($_GET["to_user"])) {
                    $chats = mysqli_query($conn, "SELECT * FROM chat_box WHERE (from_user = '" . $_SESSION["user_id"] . "')");
                    $uname = mysqli_fetch_assoc($chats);
                    ?>

                    <input type="text" value="<?php echo $_GET["to_user"] ?>" id="to_user" hidden>

                    <?php
                    echo $uname["username"];
                } else {
                    $username = mysqli_query($conn, "SELECT * FROM user_table");
                    $uname = mysqli_fetch_assoc($chats);
                    ?>

                    <input type="text" value="<?php echo $_SESSION["to_user"] ?>" id="to_user" hidden>

                    <?php
                    echo $uname["username"];
                }
                ?>
            </div>
        </div>
    </div>

</body>

</html>