-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2024 at 12:58 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `chatid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `chatroomid` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `chat_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chatid`, `userid`, `chatroomid`, `message`, `chat_date`) VALUES
(1, 6, 3, 'Kalbo', '2024-06-05 10:57:18'),
(2, 8, 3, 'Hi', '2024-06-05 10:57:47'),
(3, 6, 3, 'kalbo', '2024-06-05 11:08:03'),
(4, 8, 3, 'dasdasd', '2024-06-05 11:08:24'),
(5, 8, 3, 'sdfsdfsf', '2024-06-05 11:08:27'),
(6, 8, 3, 'asdasdasdasdasdasdasd', '2024-06-05 11:08:31'),
(7, 8, 3, 'sdfsdfsdfghjkgfdg', '2024-06-05 11:08:34'),
(8, 8, 3, 'sdfdsf', '2024-06-05 11:08:37');

-- --------------------------------------------------------

--
-- Table structure for table `chatroom`
--

CREATE TABLE `chatroom` (
  `chatroomid` int(11) NOT NULL,
  `chat_name` varchar(60) NOT NULL,
  `date_created` datetime NOT NULL,
  `chat_password` varchar(30) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chatroom`
--

INSERT INTO `chatroom` (`chatroomid`, `chat_name`, `date_created`, `chat_password`, `userid`) VALUES
(3, 'Yskah', '2017-09-11 13:21:24', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `chat_member`
--

CREATE TABLE `chat_member` (
  `chat_memberid` int(11) NOT NULL,
  `chatroomid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_member`
--

INSERT INTO `chat_member` (`chat_memberid`, `chatroomid`, `userid`) VALUES
(1, 1, 2),
(2, 2, 3),
(3, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification_table`
--

CREATE TABLE `notification_table` (
  `notification_id` int(15) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_table`
--

INSERT INTO `notification_table` (`notification_id`, `user_id`, `title`, `description`, `status`, `image_file`) VALUES
(26, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(27, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(28, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(29, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(30, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(31, 21, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', ''),
(32, 22, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details', 'Unread', ''),
(33, 21, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details', 'Unread', ''),
(34, 21, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details', 'Unread', ''),
(35, 22, 'Order Placed', 'Your Order has been placed succesfully. Click for more details', 'Unread', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(15) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('Pending','Shipping','Shipped','Delivered') DEFAULT 'Pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `user_id`, `product_id`, `product_name`, `image_file`, `price`, `quantity`, `total_price`, `status`, `order_date`) VALUES
(46, 104, 22, 1, 'Button pin', '665f05b858e09.jpg', 123, 1, 123.00, NULL, '2024-06-16 04:43:39'),
(47, 107, 22, 2, 'Glass art', '665f05ca144ef.jpg', 249, 4, 996.00, 'Pending', '2024-06-16 04:55:58'),
(48, 108, 22, 2, 'Glass art', '665f05ca144ef.jpg', 249, 1, 372.00, 'Pending', '2024-06-16 05:03:41'),
(49, 109, 22, 1, 'Button pin', '665f05b858e09.jpg', 123, 1, 372.00, 'Delivered', '2024-06-16 05:03:41'),
(50, 110, 21, 2, 'Glass art', '665f05ca144ef.jpg', 249, 1, 249.00, 'Delivered', '2024-06-16 06:59:02'),
(51, 111, 22, 2, 'Glass art', '665f05ca144ef.jpg', 249, 2, 498.00, 'Pending', '2024-06-16 08:01:01');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(15) NOT NULL,
  `product_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `variation` varchar(255) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `hot` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `image_file`, `price`, `description`, `hot`) VALUES
(1, 'Button pin', '665f05b858e09.jpg', 123, '', 0),
(2, 'Glass art', '665f05ca144ef.jpg', 249, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_samples`
--

CREATE TABLE `product_samples` (
  `sample_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_samples`
--

INSERT INTO `product_samples` (`sample_id`, `product_id`, `image_file`) VALUES
(10, 2, '666b2966cf5f8.jpg'),
(11, 2, '666b296ddefa1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(150) NOT NULL,
  `uname` varchar(60) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `access` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `uname`, `photo`, `access`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', '', 1),
(9, 'Jambik', '123', 'Jambik', '', 1),
(10, 'Jem', '123', 'Jem', '665a670e2431d_1718100348.jpg', 2),
(11, 'asd', '$2y$10$KpTGtgi2LZ0LseUjF3JSDeokxQW6I8ovsvc962lD0Gfd5hyXWXYKi', 'asd', '', 2),
(12, 'ewq', '$2y$10$jytdybm18sH4Go.okm1zlOUtL4fjJPbjBkXyxHX/oews2QJ4CnTz6', 'ewq', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(50) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `blockLot` varchar(100) NOT NULL,
  `subdivision` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `is_admin`, `first_name`, `last_name`, `sex`, `phone`, `blockLot`, `subdivision`, `barangay`, `city`, `province`, `zip`, `username`, `email`, `password`, `image_file`) VALUES
(20, 1, 'John VIctor', 'Silva', 'male', '09', '', '0', '', '', '', '', 'Jambik', 'bektor@gmail.com', '$2y$10$y0EFpR.hNLCG17lXCapiBe.My8ocW1F5nrgFdzVgJUc', '666adbbff14bf.png'),
(21, 0, 'Jem', 'Llanto', 'male', '09099', 'Blk 134 Lt 43 Ph7', 'Carrisa Homes', 'Punta 1', 'Tanza', 'Cavite', '4108', 'Jem', 'jemmmmm@gmail.com', '$2y$10$EjQ1duGqAIpUZ.EC6nkFwuVqLLsAXME6OJFSc98LqVL', '666adbbff14bf.png'),
(22, 0, 'asd', 'asd', 'female', '+639919469476', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'asd', 'asdaasd@gmail.com', '$2y$10$KpTGtgi2LZ0LseUjF3JSDeokxQW6I8ovsvc962lD0Gf', 'default-profile.jpg'),
(23, 0, 'asd', 'asd', 'Choose...', '+639919469476', 'qw', 'w', 'qwqw', 'qwqqwe', 'e', 'e', 'ewq', 'aaasd@gmail.com', '$2y$10$jytdybm18sH4Go.okm1zlOUtL4fjJPbjBkXyxHX/oew', 'default-profile.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chatroom`
--
ALTER TABLE `chatroom`
  ADD PRIMARY KEY (`chatroomid`);

--
-- Indexes for table `chat_member`
--
ALTER TABLE `chat_member`
  ADD PRIMARY KEY (`chat_memberid`);

--
-- Indexes for table `notification_table`
--
ALTER TABLE `notification_table`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_samples`
--
ALTER TABLE `product_samples`
  ADD PRIMARY KEY (`sample_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `chatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chatroom`
--
ALTER TABLE `chatroom`
  MODIFY `chatroomid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chat_member`
--
ALTER TABLE `chat_member`
  MODIFY `chat_memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notification_table`
--
ALTER TABLE `notification_table`
  MODIFY `notification_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_samples`
--
ALTER TABLE `product_samples`
  MODIFY `sample_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
